tinymce.PluginManager.add("example_dependency",function(){},["example"]);
